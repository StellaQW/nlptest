// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//		are changed infrequently
//
#define HIER_LIST
#define WIN32_LEAN_AND_MEAN
#define _USING_V110_SDK71_

#include <afxwin.h>   // MFC core and standard components
#include <afxext.h>   // MFC extensions
#include "afxpriv.h"  // for mru class.

#include "limits.h"

// allow memory leaks to give me the line number.
#define new DEBUG_NEW
